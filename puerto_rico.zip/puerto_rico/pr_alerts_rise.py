import json, numpy as np
from p1_physics import build
from eval_p1 import load_preds
out = {}
for site, depths in [('utuado', ['i_secondary', 'i_primary']), ('toronegro', ['i_primary'])]:
    B = build(site); P = load_preds(site, B); W = B['wins']; out[site] = {}
    for dk in depths:
        k = B[dk]; zname = {('utuado','i_secondary'):'57 cm',('utuado','i_primary'):'72 cm',('toronegro','i_primary'):'90 cm'}[(site,dk)]
        allv = np.concatenate([w['Y'][:, k] for w in W]); thr = float(0.2 * (np.nanpercentile(allv, 99) - np.nanpercentile(allv, 1)))
        res = {}
        models = ['R-cal', 'R-cal-Se (exploratory)'] + [f'PG-MLP s{s}' for s in range(3)]
        # common valid windows
        def pred(m, i):
            pr = P[m]
            if isinstance(pr, tuple):
                arr = pr[1] if dk == 'i_primary' else pr[2]; return arr[i]
            return None if pr[i] is None else pr[i][:, k]
        valid = []
        for i, w in enumerate(W):
            y = w['Y'][:, k].copy(); y[~w['top_ok']] = np.nan
            if np.isnan(y).mean() > 0.2: continue
            if any(pred(m, i) is None for m in models): continue
            valid.append(i)
        for m in models:
            CA = MA = FA = TN = 0; lags = []
            for i in valid:
                w = W[i]; y = w['Y'][:, k].copy(); y[~w['top_ok']] = np.nan; p = pred(m, i)
                y0 = np.nanmean(y[:4]); o = np.nanmax(y) - y0 >= thr; q = np.nanmax(p) - y0 >= thr
                CA += o and q; MA += o and not q; FA += (not o) and q; TN += (not o) and (not q)
                if o and q: lags.append((np.nanargmax(p - y0 >= thr) - np.nanargmax(y - y0 >= thr)) * 0.25)
            N = CA + MA + FA + TN
            res[m] = dict(events=int(CA + MA), N=int(N), CA=int(CA), MA=int(MA), FA=int(FA), TN=int(TN), POD=CA / max(CA + MA, 1),
                          FAR=FA / max(CA + FA, 1), CSI=CA / max(CA + MA + FA, 1), EI=(CA + TN) / N, MAR=MA / max(CA + MA, 1),
                          median_timing_h=float(np.median(lags)) if lags else None, POD_timely=float(np.sum(np.abs(lags) <= 2.0)) / max(CA + MA, 1) if lags else 0.0)
        out[site][zname] = dict(threshold=thr, results=res)
        print(site, zname, 'thr', round(thr, 3), 'N', len(valid))
        for m, r in res.items(): print('   ', m, {kk: (round(v, 2) if isinstance(v, float) else v) for kk, v in r.items()})
json.dump(out, open('out/pr_alerts_rise.json', 'w'), indent=1, default=float)
