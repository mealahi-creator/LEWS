"""P1 baseline: physics-guided MLP virtual deep sensor (same blocks, purge and windows as the physics runs).
Features at each step: shallow theta and its causal rolling means/changes, rain sums, window-start deep and shallow theta,
elapsed time. Output: deep theta through a storage-bounded form. 3 seeds. usage: python run_p1_mlp.py SITE"""
import sys, json, time, numpy as np, pandas as pd, torch, torch.nn as nn
from p1_physics import build, PURGE_H
from pr_data import SITES
torch.set_num_threads(1)
site = sys.argv[1]; NBLK = {'utuado': 10, 'toronegro': 8}[site]
B = build(site); W = B['wins']; n = len(W); c = SITES[site]; d = B['d']
blocks = np.array_split(np.arange(n), NBLK)
TARGETS = {'primary': c['deep'], 'secondary': c['deep2']}

# causal features computed on the full record (inputs only: shallow probe + rain)
sh = d[c['shallow']].interpolate(limit=8); rain = d.rain.fillna(0)
F = pd.DataFrame(index=d.index)
F['sh'] = sh
for hrs in (1, 6, 24, 72):
    F[f'sh_m{hrs}'] = sh.rolling(4 * hrs, min_periods=1).mean()
for hrs in (1, 6, 24):
    F[f'sh_d{hrs}'] = sh - sh.shift(4 * hrs)
for hrs in (1, 6, 24, 72, 168):
    F[f'r{hrs}'] = rain.rolling(4 * hrs, min_periods=1).sum()

def window_xy(i, target):
    w = W[i]; f = F.loc[w['a']:w['b']].copy()
    y = d.loc[w['a']:w['b'], target].values
    deep0 = np.nanmean(d.loc[w['a']:w['a'] + pd.Timedelta(minutes=45), target].values)
    f['deep0'] = deep0; f['sh0'] = np.nanmean(f['sh'].values[:4])
    f['elapsed'] = np.log1p(np.arange(len(f)) / 4.0)
    x = f.values.astype(np.float32)
    ok = ~np.isnan(x).any(1) & w['top_ok'] & ~np.isnan(y)
    return x, y.astype(np.float32), ok, deep0

class Net(nn.Module):
    def __init__(self, d_in, mu, sd, lo, hi):
        super().__init__(); self.mu, self.sd, self.lo, self.hi = mu, sd, lo, hi
        self.f = nn.Sequential(nn.Linear(d_in, 64), nn.SiLU(), nn.Linear(64, 64), nn.SiLU(), nn.Linear(64, 2))
    def forward(self, x):
        a = self.f((x - self.mu) / self.sd); d0 = x[:, -3]
        return d0 + (self.hi - d0) * torch.sigmoid(a[:, 0]) - (d0 - self.lo) * torch.sigmoid(a[:, 1])

def purge_train(held):
    a = min(W[i]['a'] for i in held) - pd.Timedelta(hours=PURGE_H); b = max(W[i]['b'] for i in held) + pd.Timedelta(hours=PURGE_H)
    return [j for j in range(n) if j not in set(held) and (W[j]['b'] < a or W[j]['a'] > b)]

out = {tk: {s: [None] * n for s in range(3)} for tk in TARGETS}
t0 = time.time()
for k, held in enumerate(blocks):
    tr = purge_train(list(held))
    for tk, col in TARGETS.items():
        X, Y = [], []
        for j in tr:
            x, y, ok, d0 = window_xy(j, col)
            if np.isnan(d0): continue
            X.append(x[ok]); Y.append(y[ok])
        if not X: continue
        X = torch.tensor(np.concatenate(X)); Y = torch.tensor(np.concatenate(Y))
        lo, hi = float(Y.min()) - 0.01, float(Y.max()) + 0.01
        mu, sd = X.mean(0), X.std(0).clamp_min(1e-6)
        for s in range(3):
            torch.manual_seed(s); net = Net(X.shape[1], mu, sd, lo, hi)
            opt = torch.optim.Adam(net.parameters(), lr=2e-3, weight_decay=1e-5)
            for it in range(2500):
                b = torch.randint(0, len(X), (512,))
                loss = ((net(X[b]) - Y[b]) ** 2).mean()
                opt.zero_grad(); loss.backward(); opt.step()
            with torch.no_grad():
                for i in held:
                    x, y, ok, d0 = window_xy(i, col)
                    if np.isnan(d0): continue
                    xx = np.nan_to_num(x); p = net(torch.tensor(xx)).numpy()
                    p[~ok] = np.nan; out[tk][s][i] = p
    print(f'{site} block {k} done | {time.time()-t0:.0f}s', flush=True)
np.savez_compressed(f'out/p1_mlp_{site}.npz', **{f'{tk}_s{s}': np.array(out[tk][s], dtype=object) for tk in TARGETS for s in range(3)}, allow_pickle=True)
print('done', site)
