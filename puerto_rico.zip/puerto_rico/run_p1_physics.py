"""P1 physics runs: R-cal (Levenberg-Marquardt through the JAX solver) and R-lab, leave-one-block-out.
usage: python run_p1_physics.py SITE"""
import os, sys, json, time
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
import numpy as np, pandas as pd, jax, jax.numpy as jnp
from p1_physics import build, pad, lab_params, PURGE_H
from richards_jax import simulate, pack, unpack

site = sys.argv[1]
NBLK = {'utuado': 10, 'toronegro': 8}[site]
B = build(site); W = B['wins']; n = len(W)
blocks = np.array_split(np.arange(n), NBLK)
z, oi = B['z'], B['obs_idx']
sim = jax.jit(jax.vmap(lambda p, top, th0: simulate(p, top, th0, z, oi), in_axes=(None, 0, 0)))

def resid_fn(top, th0, Y):
    m = ~jnp.isnan(Y); Yf = jnp.nan_to_num(Y)
    def r(p):
        return jnp.where(m, sim(p, top, th0) - Yf, 0.0).ravel()
    return jax.jit(r), jax.jit(jax.jacfwd(r)), int(m.sum())

def lm(r, J, nobs, p0, iters=15, lam=1e-2):
    p = jnp.array(p0); res = r(p); L = float(res @ res) / nobs; hist = [L]
    for it in range(iters):
        Jm = J(p); g = Jm.T @ res; H = Jm.T @ Jm
        while True:
            A = H + lam * jnp.diag(jnp.diag(H) + 1e-12)
            dp = -jnp.linalg.solve(A, g)
            pn = p + dp; rn = r(pn); Ln = float(rn @ rn) / nobs
            if np.isfinite(Ln) and Ln < L:
                p, res, L = pn, rn, Ln; lam = max(lam / 3, 1e-6); break
            lam *= 5
            if lam > 1e6: break
        hist.append(L)
        if lam > 1e6 or (len(hist) > 2 and hist[-2] - hist[-1] < 1e-4 * hist[-2]): break
    return np.array(p), L, hist

def purge_train(held_idx):
    a = min(W[i]['a'] for i in held_idx) - pd.Timedelta(hours=PURGE_H)
    b = max(W[i]['b'] for i in held_idx) + pd.Timedelta(hours=PURGE_H)
    return [j for j in range(n) if j not in set(held_idx) and (W[j]['b'] < a or W[j]['a'] > b)]

labs = lab_params(site)
ts_ok = lambda v: min(max(v, 0.305), 0.595)
starts = [pack(l['Ks_d'], l['a_d'], l['n_d'], ts_ok(l['ts_d']), 0.03) for l in labs] + \
         [pack(1e-3, 0.03, 1.5, 0.45, 0.02), pack(1e-2, 0.1, 1.3, 0.40, 0.02)]
lab_near = {'utuado': 'UTU-1 z=0.35 m', 'toronegro': 'ELT-1 z=0.42m'}[site]
L0 = [l for l in labs if l['sample'] == lab_near][0]
p_lab = pack(L0['Ks_d'], L0['a_d'], L0['n_d'], ts_ok(L0['ts_d']), min(L0['tr_d'], 0.0799))

os.makedirs('out', exist_ok=True)
res = dict(site=site, n_windows=n, blocks=[b.tolist() for b in blocks], folds=[])
pred_cal = [None] * n; pred_lab = [None] * n
t0 = time.time()
for k, held in enumerate(blocks):
    tr = purge_train(list(held))
    top, th0, Y = pad([W[j] for j in tr])
    r, J, nobs = resid_fn(top, th0, Y)
    Ls = [float(jnp.sum(r(jnp.array(s)) ** 2)) / nobs for s in starts]
    best = int(np.nanargmin(Ls))
    p, L, hist = lm(r, J, nobs, starts[best])
    P = {kk: float(v) for kk, v in unpack(jnp.array(p)).items()}
    # held-out predictions
    topH, th0H, YH = pad([W[i] for i in held])
    oc = np.array(sim(jnp.array(p), topH, th0H)); ol = np.array(sim(jnp.array(p_lab), topH, th0H))
    for q, i in enumerate(held):
        L_ = len(W[i]['top']); pred_cal[i] = oc[q, :L_]; pred_lab[i] = ol[q, :L_]
    res['folds'].append(dict(block=k, held=held.tolist(), n_train=len(tr), start=best, start_losses=Ls,
                             train_rmse=float(np.sqrt(L)), lm_hist=hist, params=P))
    print(f'{site} block {k}: train {len(tr)} windows, start {best}, rmse {np.sqrt(L):.4f}, '
          f'Ks {P["Ks"]:.2e} a {P["alpha"]:.3f} n {P["n"]:.2f} ts {P["ts"]:.3f} tr {P["tr"]:.3f} | {time.time()-t0:.0f}s', flush=True)
res['lab_params_used'] = {kk: float(v) for kk, v in unpack(jnp.array(p_lab)).items()}
np.savez_compressed(f'out/p1_physics_{site}.npz', cal=np.array(pred_cal, dtype=object), lab=np.array(pred_lab, dtype=object), allow_pickle=True)
json.dump(res, open(f'out/p1_physics_{site}.json', 'w'), indent=1)
print('done', site, round(time.time() - t0), 's')
