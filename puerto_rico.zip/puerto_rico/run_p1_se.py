"""EXPLORATORY (post-registration) P1 variant: R-cal-Se.
Each sensor is normalised to effective saturation with its own min/max from the TRAINING windows of the fold,
the solver runs in Se (theta_r = 0, theta_s = 1) with Ks, alpha, n calibrated, and deep predictions are mapped back
to theta with the deep sensor's training min/max. Removes sensor-calibration offsets between depths.
usage: python run_p1_se.py SITE"""
import os, sys, json, time
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
import numpy as np, pandas as pd, jax, jax.numpy as jnp
import richards_jax as R
from p1_physics import build, pad, lab_params, PURGE_H
from pr_data import SITES

site = sys.argv[1]
NBLK = {'utuado': 10, 'toronegro': 8}[site]
B = build(site); W = B['wins']; n = len(W); c = SITES[site]
blocks = np.array_split(np.arange(n), NBLK)
z, oi, tz = B['z'], B['obs_idx'], B['tz']
prof = {k * 100: v for k, v in c['profile'].items() if k * 100 >= c['z_shallow'] * 100}
zs = sorted(prof)

def P3(p):
    s = jax.nn.sigmoid
    return dict(Ks=jnp.exp(jnp.log(1e-6) + s(p[0]) * (jnp.log(1e-1) - jnp.log(1e-6))),
                alpha=jnp.exp(jnp.log(1e-3) + s(p[1]) * (jnp.log(0.5) - jnp.log(1e-3))),
                n=1.05 + s(p[2]) * 1.95, ts=1.0, tr=0.0)

def pk(Ks, a, nn):
    return R.pack(Ks, a, nn, 0.45, 0.02)[:3]

def sim1(p, top, th0):
    P = P3(p); step = R.make_step(float(z[1] - z[0]), 900.0)
    h0 = R.h_of_theta(th0, P)
    @jax.checkpoint
    def f(h, tt):
        h = step(h, R.h_of_theta(tt, P), P); return h, R.theta_of_h(h, P)[oi]
    return jax.lax.scan(f, h0, top)[1]
sim = jax.jit(jax.vmap(sim1, in_axes=(None, 0, 0)))

def ranges(idx):
    """per-depth (min, max) of theta over the given windows (all depths incl. shallow)."""
    d = B['d']; mins, maxs = {}, {}
    for q in zs:
        vals = np.concatenate([d.loc[W[i]['a']:W[i]['b'], prof[q]].values for i in idx])
        mins[q], maxs[q] = np.nanquantile(vals, 0.005), np.nanquantile(vals, 0.995)
    return mins, maxs

def to_se(wins, mins, maxs, margin=0.02):
    out = []
    for w in wins:
        f = lambda th, q: np.clip((th - mins[q]) / (maxs[q] - mins[q]) * (1 - 2 * margin) + margin, 0.0, 1.0)
        ww = dict(w)
        ww['top'] = f(w['top'], zs[0])
        # initial profile: rebuild from depths using per-depth normalisation, then interpolate
        th0_depths = np.interp(np.array(zs), z, w['th0'])
        se0 = np.array([f(th0_depths[k], q) for k, q in enumerate(zs)])
        ww['th0'] = np.interp(z, np.array(zs), se0)
        ww['Y'] = np.stack([f(w['Y'][:, k], q) for k, q in enumerate(tz)], 1)
        out.append(ww)
    return out

def back(se, q, mins, maxs, margin=0.02):
    return (se - margin) / (1 - 2 * margin) * (maxs[q] - mins[q]) + mins[q]

def lm(r, J, nobs, p0, iters=15, lam=1e-2):
    p = jnp.array(p0); res = r(p); L = float(res @ res) / nobs; hist = [L]
    for it in range(iters):
        Jm = J(p); g = Jm.T @ res; H = Jm.T @ Jm
        while True:
            dp = -jnp.linalg.solve(H + lam * jnp.diag(jnp.diag(H) + 1e-12), g)
            pn = p + dp; rn = r(pn); Ln = float(rn @ rn) / nobs
            if np.isfinite(Ln) and Ln < L:
                p, res, L = pn, rn, Ln; lam = max(lam / 3, 1e-6); break
            lam *= 5
            if lam > 1e6: break
        hist.append(L)
        if lam > 1e6 or (len(hist) > 2 and hist[-2] - hist[-1] < 1e-4 * hist[-2]): break
    return np.array(p), L, hist

def purge_train(held):
    a = min(W[i]['a'] for i in held) - pd.Timedelta(hours=PURGE_H); b = max(W[i]['b'] for i in held) + pd.Timedelta(hours=PURGE_H)
    return [j for j in range(n) if j not in set(held) and (W[j]['b'] < a or W[j]['a'] > b)]

labs = lab_params(site)
starts = [pk(l['Ks_d'], l['a_d'], l['n_d']) for l in labs] + [pk(1e-3, 0.03, 1.5), pk(1e-2, 0.1, 1.3), pk(1e-4, 0.01, 2.0)]
res = dict(site=site, mode='Se-normalised (exploratory)', folds=[]); pred = [None] * n; t0 = time.time()
for k, held in enumerate(blocks):
    tr = purge_train(list(held)); mins, maxs = ranges(tr)
    top, th0, Y = pad(to_se([W[j] for j in tr], mins, maxs))
    m = ~jnp.isnan(Y); Yf = jnp.nan_to_num(Y)
    r = jax.jit(lambda p: jnp.where(m, sim(p, top, th0) - Yf, 0.0).ravel()); J = jax.jit(jax.jacfwd(r)); nobs = int(m.sum())
    Ls = [float(jnp.sum(r(jnp.array(s)) ** 2)) / nobs for s in starts]; best = int(np.nanargmin(Ls))
    p, L, hist = lm(r, J, nobs, starts[best])
    P = {kk: float(v) for kk, v in P3(jnp.array(p)).items()}
    topH, th0H, _ = pad(to_se([W[i] for i in held], mins, maxs))
    o = np.array(sim(jnp.array(p), topH, th0H))
    for q, i in enumerate(held):
        L_ = len(W[i]['top']); pred[i] = np.stack([back(o[q, :L_, kk], tz[kk], mins, maxs) for kk in range(len(tz))], 1)
    res['folds'].append(dict(block=k, held=held.tolist(), n_train=len(tr), start=best, start_losses=Ls,
                             train_rmse_se=float(np.sqrt(L)), lm_hist=hist, params=P,
                             ranges={str(q): [float(mins[q]), float(maxs[q])] for q in zs}))
    print(f'{site} block {k}: train {len(tr)}, start {best}, rmse(Se) {np.sqrt(L):.4f}, Ks {P["Ks"]:.2e} a {P["alpha"]:.4f} n {P["n"]:.2f} | {time.time()-t0:.0f}s', flush=True)
np.savez_compressed(f'out/p1_se_{site}.npz', cal=np.array(pred, dtype=object), allow_pickle=True)
json.dump(res, open(f'out/p1_se_{site}.json', 'w'), indent=1)
print('done', site, round(time.time() - t0), 's')
