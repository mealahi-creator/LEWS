"""P4: Laplace posterior + elapsed-time-binned noise for R-cal (registered) and R-cal-Se (exploratory);
PG-MLP seed 0 + cross-conformal baseline. usage: python run_p4.py SITE MODEL   (MODEL = cal | se)"""
import os, sys, json, time
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
import numpy as np, pandas as pd, jax, jax.numpy as jnp
from p1_physics import build, pad, PURGE_H
import richards_jax as R
site, model = sys.argv[1], sys.argv[2]
B = build(site); W = B['wins']; n = len(W); z, oi, tz = B['z'], B['obs_idx'], B['tz']
kP = B['i_primary']
BINS = np.array([0, 6, 24, 48, 1e9]) * 4          # in 15-min steps
J_ = json.load(open(f'out/p1_{"physics" if model == "cal" else "se"}_{site}.json'))
rng = np.random.default_rng(0)

if model == 'cal':
    sim1 = lambda p, top, th0: R.simulate(p, top, th0, z, oi)
    to_model = lambda wins, fold: wins
    back = lambda arr, fold: arr
    npar = 5
else:
    from pr_data import SITES
    c = SITES[site]; prof = {k * 100: v for k, v in c['profile'].items() if k * 100 >= c['z_shallow'] * 100}; zs = sorted(prof)
    MG = 0.02
    def P3(p):
        s_ = jax.nn.sigmoid
        return dict(Ks=jnp.exp(jnp.log(1e-6) + s_(p[0]) * (jnp.log(1e-1) - jnp.log(1e-6))),
                    alpha=jnp.exp(jnp.log(1e-3) + s_(p[1]) * (jnp.log(0.5) - jnp.log(1e-3))), n=1.05 + s_(p[2]) * 1.95, ts=1.0, tr=0.0)
    def sim1(p, top, th0):
        P = P3(p); step = R.make_step(float(z[1] - z[0]), 900.0); h0 = R.h_of_theta(th0, P)
        def f(h, tt):
            h = step(h, R.h_of_theta(tt, P), P); return h, R.theta_of_h(h, P)[oi]
        return jax.lax.scan(f, h0, top)[1]
    npar = 3
    def rng_of(fold):
        return {float(k): v[0] for k, v in fold['ranges'].items()}, {float(k): v[1] for k, v in fold['ranges'].items()}
    def to_model(wins, fold):
        mins, maxs = rng_of(fold); outw = []
        f = lambda th, q: np.clip((th - mins[q]) / (maxs[q] - mins[q]) * (1 - 2 * MG) + MG, 0.0, 1.0)
        for w in wins:
            ww = dict(w); ww['top'] = f(w['top'], zs[0])
            th0d = np.interp(np.array(zs), z, w['th0']); ww['th0'] = np.interp(z, np.array(zs), np.array([f(th0d[k], q) for k, q in enumerate(zs)]))
            ww['Y'] = np.stack([f(w['Y'][:, k], q) for k, q in enumerate(tz)], 1); outw.append(ww)
        return outw
    def back(arr, fold):
        mins, maxs = rng_of(fold); q = tz[kP]
        return (arr - MG) / (1 - 2 * MG) * (maxs[q] - mins[q]) + mins[q]
sim = jax.jit(jax.vmap(sim1, in_axes=(None, 0, 0)))
simP = jax.jit(jax.vmap(lambda p, top, th0: jax.vmap(sim1, in_axes=(None, 0, 0))(p, top, th0), in_axes=(0, None, None)))

def purge_train(held):
    a = min(W[i]['a'] for i in held) - pd.Timedelta(hours=PURGE_H); b = max(W[i]['b'] for i in held) + pd.Timedelta(hours=PURGE_H)
    return [j for j in range(n) if j not in set(held) and (W[j]['b'] < a or W[j]['a'] > b)]

def unc_vec(P):
    if model == 'cal':
        return jnp.array(R.pack(P['Ks'], P['alpha'], P['n'], min(max(P['ts'], 0.3001), 0.5999), min(max(P['tr'], 1e-4), 0.0799)))
    return jnp.array(R.pack(P['Ks'], P['alpha'], P['n'], 0.45, 0.02)[:3])

out = {'lo': [None] * n, 'hi': [None] * n, 'med': [None] * n}; info = []
t0 = time.time()
for fold in J_['folds']:
    held = fold['held']; tr = purge_train(held)
    p = unc_vec(fold['params'])
    top, th0, Y = pad(to_model([W[j] for j in tr], fold))
    m = ~jnp.isnan(Y); Yf = jnp.nan_to_num(Y)
    r = jax.jit(lambda q: jnp.where(m, sim(q, top, th0) - Yf, 0.0).ravel())
    Jm = np.array(jax.jacfwd(r)(p)); res = np.array(r(p)); nobs = int(m.sum())
    s2 = float(res @ res) / max(nobs - npar, 1)
    cov = s2 * np.linalg.pinv(Jm.T @ Jm + 1e-10 * np.eye(npar))
    # noise by elapsed-time bin on the primary target (model units)
    pred_tr = np.array(sim(p, top, th0))[..., kP]; ytr = np.array(Y)[..., kP]
    steps = np.arange(pred_tr.shape[1])[None].repeat(pred_tr.shape[0], 0)
    sig = []
    for b0, b1 in zip(BINS[:-1], BINS[1:]):
        sel = (steps >= b0) & (steps < b1) & ~np.isnan(ytr)
        sig.append(float(np.sqrt(np.mean((pred_tr[sel] - ytr[sel]) ** 2))) if sel.any() else np.nan)
    draws = rng.multivariate_normal(np.array(p), cov, size=200)
    topH, th0H, _ = pad(to_model([W[i] for i in held], fold))
    S = np.array(simP(jnp.array(draws), topH, th0H))[..., kP]          # (200, nh, T)
    for q, i in enumerate(held):
        L = len(W[i]['top']); s = S[:, q, :L]
        sb = np.array(sig)[np.clip(np.searchsorted(BINS, np.arange(L), side='right') - 1, 0, 3)]
        yy = s + rng.standard_normal(s.shape) * sb[None]
        if model == 'se':
            yy = back(yy, fold)
        out['lo'][i] = np.quantile(yy, 0.05, 0); out['hi'][i] = np.quantile(yy, 0.95, 0); out['med'][i] = np.median(yy, 0)
    info.append(dict(block=fold['block'], sd_param_log=np.sqrt(np.diag(cov)).tolist(), sigma_bins=sig))
    print(f'{site} {model} block {fold["block"]}: sigma bins {np.round(sig, 4)} | {time.time()-t0:.0f}s', flush=True)
np.savez_compressed(f'out/p4_{model}_{site}.npz', **{k: np.array(v, dtype=object) for k, v in out.items()}, allow_pickle=True)
json.dump(info, open(f'out/p4_{model}_{site}.json', 'w'), indent=1)
print('done')
