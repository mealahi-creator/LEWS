"""EXPLORATORY screening metrics (proposed after the registered tests): vertical-consistency of storm responses.
For each deep sensor vs the sensor directly above it, per storm (24 h before to 48 h after start):
  magnitude inversion = deep rise exceeds the rise of the sensor above;
  timing inversion    = deep sensor starts rising before the sensor above (onset = pre-storm mean + 0.005)."""
import json, numpy as np, pandas as pd
from pr_data import SITES, load, storms
out = {}
for site in SITES:
    d = load(site); S = storms(d); prof = SITES[site]['profile']; zs = sorted(prof)
    for up, dn in zip(zs[:-1], zs[1:]):
        mag, tim, n = [], [], 0
        for _, st in S.iterrows():
            pre = d.loc[st.start - pd.Timedelta(hours=24): st.start]; post = d.loc[st.start: st.start + pd.Timedelta(hours=48)]
            a, b = prof[up], prof[dn]
            if post[a].notna().mean() < .8 or post[b].notna().mean() < .8 or np.isnan(pre[a].mean()) or np.isnan(pre[b].mean()): continue
            ra, rb = post[a].max() - pre[a].mean(), post[b].max() - pre[b].mean()
            if max(ra, rb) < 0.005: continue
            n += 1; mag.append(rb > ra + 0.005)
            ha, hb = post[a] > pre[a].mean() + 0.005, post[b] > pre[b].mean() + 0.005
            if ha.any() and hb.any(): tim.append(hb.idxmax() < ha.idxmax())
        out[f'{site} {int(up*100)}->{int(dn*100)} cm'] = dict(storms=n, magnitude_inversion=round(float(np.mean(mag)), 3) if mag else None,
                                                             timing_inversion=round(float(np.mean(tim)), 3) if tim else None, timing_n=len(tim))
json.dump(out, open('out/screening_metrics.json', 'w'), indent=1); print(json.dumps(out, indent=1))
