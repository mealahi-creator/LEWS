import json, numpy as np, pandas as pd
from pr_data import SITES, load, storms
out = {}
for site in SITES:
    d = load(site); S = storms(d); prof = SITES[site]['profile']; zs = sorted(prof)
    rng = {z: (d[prof[z]].quantile(.005), d[prof[z]].quantile(.995)) for z in zs}
    se = lambda z, v: (v - rng[z][0]) / (rng[z][1] - rng[z][0])
    for up, dn in zip(zs[:-1], zs[1:]):
        mag, n = [], 0
        for _, st in S.iterrows():
            pre = d.loc[st.start - pd.Timedelta(hours=24): st.start]; post = d.loc[st.start: st.start + pd.Timedelta(hours=48)]
            a, b = prof[up], prof[dn]
            if post[a].notna().mean() < .8 or post[b].notna().mean() < .8 or np.isnan(pre[a].mean()) or np.isnan(pre[b].mean()): continue
            ra, rb = se(up, post[a].max()) - se(up, pre[a].mean()), se(dn, post[b].max()) - se(dn, pre[b].mean())
            if max(ra, rb) < 0.02: continue
            n += 1; mag.append(rb > ra + 0.02)
        out[f'{site} {int(round(up*100))}->{int(round(dn*100))} cm'] = dict(storms=n, normalised_magnitude_inversion=round(float(np.mean(mag)), 3) if mag else None)
json.dump(out, open('out/screening_metrics_norm.json', 'w'), indent=1); print(json.dumps(out, indent=1))
