"""Nested selection of the normalisation percentile (inner = training windows of each fold only), generic fixed
parameters, for both Utuado and Toro Negro. Guards against choosing the percentile on held-out skill."""
import os, json, time, sys
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
site_arg = sys.argv[1]
sys.argv = ['x', site_arg]
import numpy as np, jax.numpy as jnp
exec(open('run_p1_se.py').read().split("labs = lab_params(site)")[0])
from eval_p1 import load_preds, per_window, skill, boot_diff
OPTS = [(0.005, 0.995), (0.01, 0.99), (0.025, 0.975), (0.05, 0.95)]
p = pk(1e-2, 0.1, 1.3)
def ranges_q(idx, lo, hi):
    d = B['d']; mins, maxs = {}, {}
    for q in zs:
        vals = np.concatenate([d.loc[W[i]['a']:W[i]['b'], prof[q]].values for i in idx])
        mins[q], maxs[q] = np.nanquantile(vals, lo), np.nanquantile(vals, hi)
    return mins, maxs
def run(idx, mins, maxs):
    top, th0, _ = pad(to_se([W[i] for i in idx], mins, maxs)); o = np.array(sim(jnp.array(p), top, th0)); out = []
    for q, i in enumerate(idx):
        L_ = len(W[i]['top']); out.append(np.stack([back(o[q, :L_, kk], tz[kk], mins, maxs) for kk in range(len(tz))], 1))
    return out
kP, kS = B['i_primary'], B['i_secondary']
pred = [None] * n; chosen = []
for k, held in enumerate(blocks):
    tr = purge_train(list(held)); best = None
    for lo, hi in OPTS:
        mins, maxs = ranges_q(tr, lo, hi); pr = run(tr, mins, maxs); se = 0.0
        for j, i in enumerate(tr):
            y = W[i]['Y'].copy(); y[~W[i]['top_ok']] = np.nan
            for kk in (kP, kS):
                ok = ~np.isnan(y[:, kk]); se += np.sum((pr[j][ok, kk] - y[ok, kk]) ** 2)
        if best is None or se < best[0]: best = (se, lo, hi)
    chosen.append(best[1:]); mins, maxs = ranges_q(tr, best[1], best[2])
    for q, i in zip(held, run(list(held), mins, maxs)): pred[q] = q and pred[q]; pred[q] = i
    print('fold', k, 'chosen', best[1:], flush=True)
P = load_preds(site, B); P['Se nested'] = np.array(pred, dtype=object)
out = {'chosen': chosen}
for which in ('secondary', 'primary'):
    rows = per_window(B, P, which)
    valid = [np.where(~np.isnan(r[0]) & (r[2] > 0))[0] for r in rows.values()]
    common = np.array(sorted(set.intersection(*[set(v) for v in valid])))
    sk = {nm: float(skill(r[0], r[1], common)) for nm, r in rows.items()}
    d = {s: [sk['Se nested'] - sk[f'PG-MLP s{s}'], boot_diff(rows['Se nested'], rows[f'PG-MLP s{s}'], common, B=5000)] for s in range(3)}
    out[which] = dict(n=int(len(common)), skill=sk, diff=d)
    print(which, {k2: round(v, 3) for k2, v in sk.items()}); print('  diff', d)
json.dump(out, open(f'out/se_nested_{site}.json', 'w'), indent=1, default=float)
