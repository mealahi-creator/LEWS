import os, json, sys
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
sys.argv = ['x', 'utuado']
import numpy as np, jax.numpy as jnp
exec(open('run_p1_se.py').read().split("labs = lab_params(site)")[0])
from eval_p1 import load_preds, per_window, skill
p = pk(1e-2, 0.1, 1.3)
def ranges_q(idx, lo, hi):
    d = B['d']; mins, maxs = {}, {}
    for q in zs:
        vals = np.concatenate([d.loc[W[i]['a']:W[i]['b'], prof[q]].values for i in idx])
        mins[q], maxs[q] = np.nanquantile(vals, lo), np.nanquantile(vals, hi)
    return mins, maxs
def run(idx, mins, maxs):
    top, th0, _ = pad(to_se([W[i] for i in idx], mins, maxs)); o = np.array(sim(jnp.array(p), top, th0)); out = []
    for q, i in enumerate(idx):
        L_ = len(W[i]['top']); out.append(np.stack([back(o[q, :L_, kk], tz[kk], mins, maxs) for kk in range(len(tz))], 1))
    return out
res = {}
for lo, hi in [(0.05, 0.95), (0.1, 0.9), (0.15, 0.85), (0.2, 0.8)]:
    pred = [None] * n; trainse = 0
    for k, held in enumerate(blocks):
        tr = purge_train(list(held)); mins, maxs = ranges_q(tr, lo, hi)
        for q, pr in zip(held, run(list(held), mins, maxs)): pred[q] = pr
    P = load_preds(site, B); P['X'] = np.array(pred, dtype=object); r = {}
    for which in ('secondary', 'primary'):
        rows = per_window(B, P, which); valid = [np.where(~np.isnan(rr[0]) & (rr[2] > 0))[0] for rr in rows.values()]
        common = np.array(sorted(set.intersection(*[set(v) for v in valid]))); r[which] = float(skill(*rows['X'][:2], common))
    res[f'{lo}-{hi}'] = r; print(lo, hi, r, flush=True)
    if (lo, hi) == (0.05, 0.95): np.savez_compressed('out/se_nested_utuado_pred.npz', pred=np.array(pred, dtype=object), allow_pickle=True)
json.dump(res, open('out/se_grid_wide.json', 'w'), indent=1)
