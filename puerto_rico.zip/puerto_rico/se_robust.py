"""Robustness of the exploratory R-cal-Se result at Utuado: fixed (uncalibrated) parameters and alternative
normalisation percentiles. Same folds, purge and evaluation as the main analysis."""
import os, json, time
os.environ.setdefault('XLA_FLAGS', '--xla_cpu_multi_thread_eigen=false intra_op_parallelism_threads=1')
import sys; sys.argv = ['x', 'utuado']
import numpy as np, jax.numpy as jnp
exec(open('run_p1_se.py').read().split("labs = lab_params(site)")[0])   # reuse definitions
from eval_p1 import load_preds, per_window, skill, boot_diff
labs = lab_params(site)
def ranges_q(idx, lo, hi):
    d = B['d']; mins, maxs = {}, {}
    for q in zs:
        vals = np.concatenate([d.loc[W[i]['a']:W[i]['b'], prof[q]].values for i in idx])
        mins[q], maxs[q] = np.nanquantile(vals, lo), np.nanquantile(vals, hi)
    return mins, maxs
VARIANTS = {'generic fixed (0.5–99.5%)': (pk(1e-2, 0.1, 1.3), (0.005, 0.995))}
for l, nm in zip(labs, ['22', '57', '92']):
    VARIANTS[f'lab {nm} cm fixed (0.5–99.5%)'] = (pk(l['Ks_d'], l['a_d'], l['n_d']), (0.005, 0.995))
for lo, hi in [(0.01, 0.99), (0.025, 0.975), (0.05, 0.95)]:
    VARIANTS[f'generic fixed ({lo*100:g}–{hi*100:g}%)'] = (pk(1e-2, 0.1, 1.3), (lo, hi))
preds = {}
for name, (p, (lo, hi)) in VARIANTS.items():
    t0 = time.time(); pred = [None] * n
    for k, held in enumerate(blocks):
        tr = purge_train(list(held)); mins, maxs = ranges_q(tr, lo, hi)
        topH, th0H, _ = pad(to_se([W[i] for i in held], mins, maxs))
        o = np.array(sim(jnp.array(p), topH, th0H))
        for q, i in enumerate(held):
            L_ = len(W[i]['top']); pred[i] = np.stack([back(o[q, :L_, kk], tz[kk], mins, maxs) for kk in range(len(tz))], 1)
    preds[name] = np.array(pred, dtype=object); print(name, round(time.time() - t0), 's', flush=True)
P = load_preds(site, B); P.update(preds)
out = {}
for which in ('secondary', 'primary'):
    rows = per_window(B, P, which)
    valid = [np.where(~np.isnan(r[0]) & (r[2] > 0))[0] for r in rows.values()]
    common = np.array(sorted(set.intersection(*[set(v) for v in valid])))
    sk = {nm: float(skill(r[0], r[1], common)) for nm, r in rows.items()}
    diffs = {}
    for nm in list(VARIANTS) + ['R-cal-Se (exploratory)']:
        diffs[nm] = {s: [sk[nm] - sk[f'PG-MLP s{s}'], boot_diff(rows[nm], rows[f'PG-MLP s{s}'], common, B=5000)] for s in range(3)}
    out[which] = dict(n=int(len(common)), skill=sk, diff_vs_pgmlp=diffs)
    print(which, len(common)); [print('  %-32s %.3f' % (k, v)) for k, v in sk.items()]
json.dump(out, open('out/se_robust.json', 'w'), indent=1, default=float)
