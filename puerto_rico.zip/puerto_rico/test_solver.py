import numpy as np, pandas as pd, jax, jax.numpy as jnp, time
from pr_data import *
from richards_jax import *
site='utuado'; c=SITES[site]; d=load(site); S=storms(d)
zs=c['z_shallow']*100; zb=c['z_base']*100; dz=2.5
z=np.arange(zs, zb+1e-6, dz); print('nodes', len(z), z[:3], z[-1])
obs_z=[42,57,72]; obs_idx=np.array([np.argmin(abs(z-q)) for q in obs_z]); print('obs nodes', z[obs_idx])
st=S.iloc[10]; w=window(d,st)
prof_z=np.array(sorted(c['profile'])) * 100
def init_prof(row):
    vals=np.array([row[c['profile'][k/100]] for k in prof_z])
    ok=~np.isnan(vals); return np.interp(z, prof_z[ok], vals[ok])
th0=init_prof(w.iloc[0]); top=w[c['shallow']].interpolate(limit=8).ffill().values
# lab params (UTU z=0.35 m drying, i.e., 0.57 m depth): Ks 4.09e-3 cm/s, a 0.08, n 1.47; use tr 0.03 (obs min < lab tr), ts 0.45
p=pack(4.09e-3, 0.08, 1.47, 0.45, 0.03)
f=jax.jit(lambda p, top, th0: simulate(p, top, th0, z, obs_idx))
t=time.time(); out=np.array(f(p, jnp.array(top), jnp.array(th0))); print('first call', round(time.time()-t,2),'s')
t=time.time(); out=np.array(f(p, jnp.array(top), jnp.array(th0))); print('second', round(time.time()-t,3),'s', len(top),'steps')
print('rain', st.rain_mm, 'obs 72 start/max', w[c['deep']].iloc[0], w[c['deep']].max(), '| model 72 start/max', out[0,2], out[:,2].max(), 'nan?', np.isnan(out).any())
for k,zq in enumerate(obs_z):
    o=w[c['profile'][zq/100]].values; m=out[:,k]; ok=~np.isnan(o)
    print(zq,'obs range',np.nanmin(o).round(3),np.nanmax(o).round(3),'model range',m.min().round(3),m.max().round(3),'rmse',np.sqrt(np.mean((o[ok]-m[ok])**2)).round(4),
          'rmse no-change', np.sqrt(np.mean((o[ok]-o[ok][0])**2)).round(4))
g=jax.jit(jax.grad(lambda p: jnp.mean((f(p, jnp.array(top), jnp.array(th0))[:,2]-jnp.nan_to_num(jnp.array(w[c['deep']].values), nan=0.2))**2)))
t=time.time(); gr=g(jnp.array(p)); print('grad', np.array(gr), round(time.time()-t,2),'s')
t=time.time(); gr=g(jnp.array(p)); print('grad 2nd', round(time.time()-t,3),'s')
